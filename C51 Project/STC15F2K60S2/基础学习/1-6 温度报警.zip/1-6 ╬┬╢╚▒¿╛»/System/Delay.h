#include <STC15F2K60S2.H>
#include "Sys.h"

#ifndef _Delay_H_
#define _Delay_H_

void delay_ms(uint32_t ms);
void delay_us(uint32_t us);

#endif
