#ifndef _BUZZER_H_
#define _BUZZER_H_

void BUZZER_ON(void);
void BUZZER_OFF(void);
void BUZZER_Flash(void);

#endif