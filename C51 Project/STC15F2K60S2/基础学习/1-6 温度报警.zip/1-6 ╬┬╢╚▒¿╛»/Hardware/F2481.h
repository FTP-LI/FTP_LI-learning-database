#ifndef _F2481_H_
#define _F2481_H_

#include "Sys.h"

void F24811_display(uint8_t weishu,uint8_t DATA);
void F24811_freshall(uint16_t number);

#endif
