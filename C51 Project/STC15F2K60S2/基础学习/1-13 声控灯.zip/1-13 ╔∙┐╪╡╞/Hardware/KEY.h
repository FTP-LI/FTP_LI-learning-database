#ifndef _KEY_H_
#define _KEY_H_

#include "Sys.h"

uint8_t key_scan(void);
uint8_t signkey(void);

#endif
