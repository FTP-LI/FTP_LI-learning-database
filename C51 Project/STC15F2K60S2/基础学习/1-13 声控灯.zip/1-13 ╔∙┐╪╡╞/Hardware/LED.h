#ifndef _LED_H_
#define _LED_H_

void LED_ON(void);
void LED_OFF(void);
void LED_Falsh(void);

#endif
