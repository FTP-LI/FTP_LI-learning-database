#ifndef _Sys_H_
#define _Sys_H_

#include <STC15F2K60S2.H>


#define  uint8_t   unsigned char  
#define  uint16_t  unsigned int
#define  uint32_t  unsigned long
	
#endif
